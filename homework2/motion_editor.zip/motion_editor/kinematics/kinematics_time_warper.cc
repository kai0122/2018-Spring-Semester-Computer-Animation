#include "kinematics_time_warper.h"
#include <utility>
#include "boost/numeric/conversion/cast.hpp"
#include "math_utils.h"

namespace kinematics {

// public func.

TimeWarper::TimeWarper()
    :original_motion_sequence_(new math::SpatialTemporalVector6d_t),
    hard_constraint_coll_(new TimeWarpHardConstraintColl_t),
    time_step_(double{0.0}),
    min_time_step_(double{0.0}),
    max_time_step_(double{0.0})
{
}

TimeWarper::~TimeWarper()
{
}

double TimeWarper::time_step() const
{
    return time_step_;
}

double TimeWarper::min_time_step() const
{
    return min_time_step_;
}

double TimeWarper::max_time_step() const
{
    return max_time_step_;
}

void TimeWarper::Configure(
        const math::SpatialTemporalVector6d_t &original_motion_sequence,
        const double time_step,
        const double min_time_step,
        const double max_time_step
        )
{
    *original_motion_sequence_ = original_motion_sequence;
    time_step_ = time_step;
    min_time_step_ = min_time_step;
    max_time_step_ = max_time_step;
}

math::SpatialTemporalVector6d_t TimeWarper::ComputeWarpedMotion(
        const TimeWarpHardConstraintColl_t &hard_constraint_coll
        )
{
    // TO DO
    *hard_constraint_coll_ = hard_constraint_coll;
	//param_->value<int32_t>("time_warp.desired_catch_frame_idx�);
	//std::cout << "1: " << original_motion_sequence_.get()->spatial_size() << std::endl;
	//std::cout << "2: " << original_motion_sequence_.get()->temporal_size() << std::endl;
	//std::cout << hard_constraint_coll_->size() << std::endl;
	/*
	for (int i = 0; i < hard_constraint_coll_->size(); i++){
		std::cout << hard_constraint_coll[i].frame_idx << ", " << hard_constraint_coll[i].play_second << std::endl;
	}
	for (int i0 = 0; i0 < original_motion_sequence_.get()->spatial_size(); i0++){
		std::cout << i0 << "   ********************\n";
		for (int i = 0; i < 5; i++){
			std::cout << i << ": \n";
			std::cout << original_motion_sequence_->element(i0, i) << std::endl;
		}
	}
	*/
	int NUM = 170;
	math::SpatialTemporalVector6d_t new_motion_seq;
	new_motion_seq.Resize(original_motion_sequence_.get()->spatial_size(), original_motion_sequence_.get()->temporal_size());
	for (int i = 0; i < original_motion_sequence_.get()->temporal_size(); i++){
		if (i < NUM){
			for (int j = 0; j < original_motion_sequence_.get()->spatial_size(); j++){
				double low = i * 160 / NUM;
				double high = low + 1;
				//std::cout << "i: " << i << ",low: " << low << ",high: " << high << std::endl;
				//std::cout << original_motion_sequence_.get()->element(j, low) << "\n/////////\n";
				//std::cout << original_motion_sequence_.get()->element(j, high) << "\n/////////\n";
				
				double rxLow = math::ToRadian(original_motion_sequence_.get()->element(j, low)[0]);
				double ryLow = math::ToRadian(original_motion_sequence_.get()->element(j, low)[1]);
				double rzLow = math::ToRadian(original_motion_sequence_.get()->element(j, low)[2]);
				double txLow = original_motion_sequence_.get()->element(j, low)[3];
				double tyLow = original_motion_sequence_.get()->element(j, low)[4];
				double tzLow = original_motion_sequence_.get()->element(j, low)[5];
				double rxHigh = math::ToRadian(original_motion_sequence_.get()->element(j, high)[0]);
				double ryHigh = math::ToRadian(original_motion_sequence_.get()->element(j, high)[1]);
				double rzHigh = math::ToRadian(original_motion_sequence_.get()->element(j, high)[2]);
				double txHigh = original_motion_sequence_.get()->element(j, high)[3];
				double tyHigh = original_motion_sequence_.get()->element(j, high)[4];
				double tzHigh = original_motion_sequence_.get()->element(j, high)[5];
				math::RotMat3d_t mat1;
				mat1 = math::ComputeRotMatXyz(rxLow, ryLow, rzLow);
				Eigen::Quaterniond qLow(mat1);
				math::RotMat3d_t mat2;
				mat2 = math::ComputeRotMatXyz(rxHigh, ryHigh, rzHigh);
				Eigen::Quaterniond qHigh(mat2);
				
				Eigen::Quaterniond middle = qLow.slerp(0, qHigh);
				math::Vector3d_t middleAxisRadian = math::ComputeEulerAngleXyz(middle.toRotationMatrix());
				math::Vector3d_t middleAxis(math::ToDegree(middleAxisRadian[0]), math::ToDegree(middleAxisRadian[1]), math::ToDegree(middleAxisRadian[2]));
				math::Vector3d_t middlePoint((txLow + txHigh) / 2, (tyLow + tyHigh) / 2, (tzLow + tzHigh) / 2);
				math::Vector6d_t newElement(middleAxis, middlePoint);
				new_motion_seq.set_element(j, i, newElement);
			}
		}
		else{
			for (int j = 0; j < original_motion_sequence_.get()->spatial_size(); j++){
				double low = (i - NUM) * (original_motion_sequence_.get()->temporal_size() - 160) / (original_motion_sequence_.get()->temporal_size() - NUM) + 160;
				if (low >= original_motion_sequence_.get()->temporal_size())
					low = original_motion_sequence_.get()->temporal_size() - 1;
				double high = low + 1;
				if (high >= original_motion_sequence_.get()->temporal_size())
					high = original_motion_sequence_.get()->temporal_size() - 1;
				//std::cout << "i: " << i << ",low: " << low << ",high: " << high << std::endl;
				//std::cout << original_motion_sequence_.get()->element(j, low) << "\n/////////\n";
				//std::cout << original_motion_sequence_.get()->element(j, high) << "\n/////////\n";
				double rxLow = math::ToRadian(original_motion_sequence_.get()->element(j, low)[0]);
				double ryLow = math::ToRadian(original_motion_sequence_.get()->element(j, low)[1]);
				double rzLow = math::ToRadian(original_motion_sequence_.get()->element(j, low)[2]);
				double txLow = original_motion_sequence_.get()->element(j, low)[3];
				double tyLow = original_motion_sequence_.get()->element(j, low)[4];
				double tzLow = original_motion_sequence_.get()->element(j, low)[5];
				double rxHigh = math::ToRadian(original_motion_sequence_.get()->element(j, high)[0]);
				double ryHigh = math::ToRadian(original_motion_sequence_.get()->element(j, high)[1]);
				double rzHigh = math::ToRadian(original_motion_sequence_.get()->element(j, high)[2]);
				double txHigh = original_motion_sequence_.get()->element(j, high)[3];
				double tyHigh = original_motion_sequence_.get()->element(j, high)[4];
				double tzHigh = original_motion_sequence_.get()->element(j, high)[5];
				math::RotMat3d_t mat1;
				mat1 = math::ComputeRotMatXyz(rxLow, ryLow, rzLow);
				Eigen::Quaterniond qLow(mat1);
				math::RotMat3d_t mat2;
				mat2 = math::ComputeRotMatXyz(rxHigh, ryHigh, rzHigh);
				Eigen::Quaterniond qHigh(mat2);

				Eigen::Quaterniond middle = qLow.slerp(0, qHigh);
				math::Vector3d_t middleAxisRadian = math::ComputeEulerAngleXyz(middle.toRotationMatrix());
				math::Vector3d_t middleAxis(math::ToDegree(middleAxisRadian[0]), math::ToDegree(middleAxisRadian[1]), math::ToDegree(middleAxisRadian[2]));
				math::Vector3d_t middlePoint((txLow + txHigh) / 2, (tyLow + tyHigh) / 2, (tzLow + tzHigh) / 2);
				math::Vector6d_t newElement(middleAxis, middlePoint);
				new_motion_seq.set_element(j, i, newElement);
			}
		}
	}
	
	return new_motion_seq;
}

// protected func.

// private func.

} // namespace kinematics {
