#include "kinematics_forward_solver.h"
#include <algorithm>
#include "math_utils.h"
#include "acclaim_skeleton.h"
#include "acclaim_motion.h"
#include "helper_forward_kinematics.h"
#include "kinematics_artic_idx.h"
#include "kinematics_pose.h"

namespace kinematics {

// public func.

ForwardSolver::ForwardSolver()
    :skeleton_(nullptr),
    motion_(nullptr),
    artic_path_(new ArticIdxColl_t),
    helper_fk_(new helper::ForwardKinematics)
{
}

ForwardSolver::~ForwardSolver()
{
}

std::shared_ptr<acclaim::Skeleton> ForwardSolver::skeleton() const
{
    return skeleton_;
}

std::shared_ptr<acclaim::Motion> ForwardSolver::motion() const
{
    return motion_;
}

void ForwardSolver::set_skeleton(const std::shared_ptr<acclaim::Skeleton> &skeleton)
{
    skeleton_ = skeleton;
    helper_fk_->set_skeleton(skeleton_);
}

void ForwardSolver::set_motion(const std::shared_ptr<acclaim::Motion> &motion)
{
    motion_ = motion;
    //helper_fk_->set_skeleton(skeleton_);
	helper_fk_->set_motion(motion_);

}

void ForwardSolver::ConstructArticPath()
{
    helper_fk_->ConstructArticPath();
}

PoseColl_t ForwardSolver::ComputeSkeletonPose(const int32_t frame_idx)
{
	//std::cout << frame_idx << std::endl;
    return this->ComputeSkeletonPose(motion_->joint_spatial_pos(frame_idx));
}

PoseColl_t ForwardSolver::ComputeSkeletonPose(const math::Vector6dColl_t &joint_spatial_pos)
{
    // TO DO

	using namespace Eigen;
	PoseColl_t ans;
	Pose newPose;

	math::RotMat3d_t mat;
	math::RotMat3d_t mat0;
	
	//	***************************************************
	//					Calculate Root
	//	***************************************************

	newPose.set_start_pos(math::Vector3d_t(joint_spatial_pos[0][3], joint_spatial_pos[0][4], joint_spatial_pos[0][5]));
	mat0(0, 0) = this->skeleton().get()->root_bone()->rot_parent_current[0][0];
	mat0(1, 0) = this->skeleton().get()->root_bone()->rot_parent_current[1][0];
	mat0(2, 0) = this->skeleton().get()->root_bone()->rot_parent_current[2][0];
	mat0(0, 1) = this->skeleton().get()->root_bone()->rot_parent_current[0][1];
	mat0(1, 1) = this->skeleton().get()->root_bone()->rot_parent_current[1][1];
	mat0(2, 1) = this->skeleton().get()->root_bone()->rot_parent_current[2][1];
	mat0(0, 2) = this->skeleton().get()->root_bone()->rot_parent_current[0][2];
	mat0(1, 2) = this->skeleton().get()->root_bone()->rot_parent_current[1][2];
	mat0(2, 2) = this->skeleton().get()->root_bone()->rot_parent_current[2][2];
	double x = math::ToRadian(joint_spatial_pos[0][0]), y = math::ToRadian(joint_spatial_pos[0][1]), z = math::ToRadian(joint_spatial_pos[0][2]);
	math::RotMat3d_t mat2;
	mat2 = math::ComputeRotMatXyz(x, y, z);
	Quaterniond q0(mat0);
	Quaterniond q2(mat2);
	Quaterniond q = q0 * q2;
	Quaterniond p;
	p.w() = 0;
	p.vec() = this->skeleton().get()->bone_local_dir(0) * this->skeleton().get()->bone_length(0);
	Quaterniond pRotate = q * p * q.inverse();
	mat = q.toRotationMatrix();
	
	newPose.set_rotation(mat);
	newPose.set_end_pos(newPose.start_pos() + math::Vector3d_t(pRotate.vec()));
	ans.push_back(newPose);

	//	***************************************************
	//					Traverse All
	//	***************************************************

	for (int i = 1; i < joint_spatial_pos.size(); i++){
		newPose.set_start_pos(ans[this->skeleton().get()->bone_ptr(i)->parent->idx].end_pos());
		mat = ans[this->skeleton().get()->bone_ptr(i)->parent->idx].rotation();
		math::RotMat3d_t temp;
		temp(0, 0) = this->skeleton().get()->bone_ptr(i)->rot_parent_current[0][0];
		temp(1, 0) = this->skeleton().get()->bone_ptr(i)->rot_parent_current[1][0];
		temp(2, 0) = this->skeleton().get()->bone_ptr(i)->rot_parent_current[2][0];
		temp(0, 1) = this->skeleton().get()->bone_ptr(i)->rot_parent_current[0][1];
		temp(1, 1) = this->skeleton().get()->bone_ptr(i)->rot_parent_current[1][1];
		temp(2, 1) = this->skeleton().get()->bone_ptr(i)->rot_parent_current[2][1];
		temp(0, 2) = this->skeleton().get()->bone_ptr(i)->rot_parent_current[0][2];
		temp(1, 2) = this->skeleton().get()->bone_ptr(i)->rot_parent_current[1][2];
		temp(2, 2) = this->skeleton().get()->bone_ptr(i)->rot_parent_current[2][2];
		mat *= temp.transpose();
		
		double x = math::ToRadian(joint_spatial_pos[i][0]), y = math::ToRadian(joint_spatial_pos[i][1]), z = math::ToRadian(joint_spatial_pos[i][2]);
		math::RotMat3d_t mat2;
		mat2 = math::ComputeRotMatXyz(x, y, z);
		Quaterniond q0(mat);
		Quaterniond q2(mat2);
		Quaterniond q = q0 * q2;
		Quaterniond p;
		p.w() = 0;
		p.vec() = this->skeleton().get()->bone_local_dir(i) * this->skeleton().get()->bone_length(i);
		Quaterniond pRotate = q * p * q.inverse();
		mat = q.toRotationMatrix();

		newPose.set_rotation(mat);
		newPose.set_end_pos(newPose.start_pos() + math::Vector3d_t(pRotate.vec()));
		ans.push_back(newPose);
	}

	return ans;
}

// protected func.

// private func.

} // namespace kinematics {
