#include "console_color.h"

namespace console {

int32_t White()
{
    return int32_t{7};
}

int Red()
{
    return int32_t{4};
}

int32_t Yellow()
{
    return int32_t{14};
}

int32_t Cyan()
{
    return int32_t{11};
}

int32_t Green()
{
    return int32_t{10};
}

int32_t Blue()
{
    return int32_t{9};
}

} // namespace console {
