#ifndef _MATH_FWD_H_
#define _MATH_FWD_H_

namespace math {
class LinearSystemSolver;
class PseudoinverseSolver;
} // namespace math {

#endif // #ifndef _MATH_FWD_H_
