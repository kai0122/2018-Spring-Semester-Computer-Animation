#include "math_pseudoinverse_solver.h"

namespace math {

// public func.

const char *PseudoinverseSolver::tag()
{
    return "PseudoinverseSolver";
}

PseudoinverseSolver::PseudoinverseSolver()
    :LinearSystemSolver()
{
}

PseudoinverseSolver::~PseudoinverseSolver()
{
}

std::string PseudoinverseSolver::id() const
{
    return std::string(PseudoinverseSolver::tag());
}

math::VectorNd_t PseudoinverseSolver::Solve(
        const math::MatrixN_t &coef_mat,
        const math::VectorNd_t &desired_vector
        ) const
{//TO DO
	//std::cout << "ONE:\n";
	//std::cout << coef_mat.transpose() << std::endl;
	//std::cout << "TWO:\n";
	//std::cout << desired_vector << std::endl;
	//std::cout << "THREE:\n";
	//std::cout << (coef_mat * coef_mat.transpose()).inverse() * desired_vector << std::endl;
	//std::cout << "vector:\n" << std::endl;
	//std::cout << desired_vector << std::endl;
	//std::cout << "///////////\n" << std::endl;
	//math::VectorNd_t returnVec((coef_mat.transpose() * coef_mat).inverse() * coef_mat.transpose() * desired_vector);
	math::VectorNd_t returnVec(coef_mat.transpose() * (coef_mat * coef_mat.transpose()).inverse() * desired_vector);
	//math::VectorNd_t returnVec(coef_mat.transpose() * desired_vector);
	//Eigen::MatrixXd A = coef_mat;
	//math::VectorNd_t returnVec = A.completeOrthogonalDecomposition().pseudoInverse();
	return returnVec;
}

// protected func.

// private func.

} // namespace math {
