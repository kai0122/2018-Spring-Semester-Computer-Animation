#ifndef _GUI_FL_FWD_H_
#define _GUI_FL_FWD_H_

class Fl_Button;
class Fl_Light_Button;
class Fl_Value_Slider;
class Fl_Value_Input;

#endif // #ifndef _GUI_FL_FWD_H_
