#ifndef _HELPER_FWD_H_
#define _HELPER_FWD_H_

namespace helper {
class ForwardKinematics;
} // namespace helper {

#endif // #ifndef _HELPER_FWD_H_
