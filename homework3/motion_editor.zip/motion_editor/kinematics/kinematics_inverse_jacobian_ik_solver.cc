#include "kinematics_inverse_jacobian_ik_solver.h"
#include <limits>
#include "console_log.h"
#include "math_utils.h"
#include "math_linear_system_solver.h"
#include "acclaim_skeleton.h"
#include "acclaim_motion.h"
#include "kinematics_forward_solver.h"
#include "kinematics_pose.h"

namespace kinematics {

InverseJacobianIkSolver::InverseJacobianIkSolver()
    :skeleton_(nullptr),
    fk_solver_(new ForwardSolver),
    step_(double{0.0}),
    distance_epsilon_(double{0.0}),
    max_iteration_num_(0),
    linear_system_solver_(nullptr)
{
}

InverseJacobianIkSolver::~InverseJacobianIkSolver()
{
}

void InverseJacobianIkSolver::Configure(
        const std::shared_ptr<acclaim::Skeleton> &skeleton,
        const std::shared_ptr<math::LinearSystemSolver> &linear_system_solver,
        const double step,
        const double distance_epsilon,
        const int32_t max_iteration_num
        )
{
    skeleton_ = skeleton;
    fk_solver_->set_skeleton(skeleton_);
    fk_solver_->ConstructArticPath();

    linear_system_solver_ = linear_system_solver;

    step_ = step;
    distance_epsilon_ = distance_epsilon;
    max_iteration_num_ = max_iteration_num;
}

math::Vector6dColl_t InverseJacobianIkSolver::Solve(
        const math::Vector3d_t &target_pos,
        const int32_t start_bone_idx,
        const int32_t end_bone_idx,
        const math::Vector6dColl_t &original_whole_body_joint_pos6d
        )
{//TO DO

	math::Vector6dColl_t ans(original_whole_body_joint_pos6d);
	PoseColl_t pose = fk_solver_->ComputeSkeletonPose(ans);
	
	int num = 0;
	while (num++ < max_iteration_num_ && sqrt((target_pos[0] - pose[end_bone_idx].end_pos()[0]) * (target_pos[0] - pose[end_bone_idx].end_pos()[0]) + (target_pos[1] - pose[end_bone_idx].end_pos()[1]) * (target_pos[1] - pose[end_bone_idx].end_pos()[1]) + (target_pos[2] - pose[end_bone_idx].end_pos()[2]) * (target_pos[2] - pose[end_bone_idx].end_pos()[2])) > distance_epsilon_){
		
		//	************************************
		//		Initialize Jacobian Matrix
		//	************************************

		math::MatrixN_t JacobianMat(3, 3 * (end_bone_idx - (start_bone_idx - 4) + 1));
		JacobianMat.setConstant(0);

		//	************************************
		//		Calculate Jacobian Matrix
		//	************************************

		for (int j = start_bone_idx - 4; j <= end_bone_idx; ++j){
			int colIndex = (j - start_bone_idx + 4) * 3;
			int index = j;
			if (j < start_bone_idx - 1)	//	lower back to start bone
				index = j - 10;

			math::Vector3d_t e = pose[end_bone_idx].end_pos();
			math::Vector3d_t ri = pose[index].start_pos();
			math::Vector3d_t dist = e - ri;
			
			//	Calculate X Axis
			JacobianMat.col(colIndex) = pose[index].rotation().col(0).normalized().cross(dist);
			//	Calculate Y Axis
			JacobianMat.col(colIndex + 1) = pose[index].rotation().col(1).normalized().cross(dist);
			//	Calculate Z Axis
			JacobianMat.col(colIndex + 2) = pose[index].rotation().col(2).normalized().cross(dist);
		}

		math::VectorNd_t thetaDot = linear_system_solver_.get()->Solve(JacobianMat, target_pos - pose[end_bone_idx].end_pos());
		for (int i = start_bone_idx; i <= end_bone_idx; i++){
			Eigen::Matrix3d m;
			m = Eigen::AngleAxisd(thetaDot[(i - start_bone_idx + 4) * 3 + 0] * M_PI, Eigen::Vector3d::UnitX())
				* Eigen::AngleAxisd(thetaDot[(i - start_bone_idx + 4) * 3 + 1] * M_PI, Eigen::Vector3d::UnitY())
				* Eigen::AngleAxisd(thetaDot[(i - start_bone_idx + 4) * 3 + 2] * M_PI, Eigen::Vector3d::UnitZ());

			math::Vector3d_t delta;
			delta = math::ComputeEulerAngleXyz(m);
			ans[i].set_angular_vector(ans[i].angular_vector() + step_ * delta);
		}

		pose = fk_solver_->ComputeSkeletonPose(ans);
	}

	//return original_whole_body_joint_pos6d;
	return ans;
}

} // namespace kinematics {

