#ifndef _PARAM_FWD_H_
#define _PARAM_FWD_H_

namespace param {
class XmlParser;
class Config;
} // namespace param {

#endif // #ifndef _PARAM_FWD_H_
