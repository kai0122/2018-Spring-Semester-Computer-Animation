#ifndef _GEOMETRY_DEF_H_
#define _GEOMETRY_DEF_H_

#include "global_def.h"

#endif // #ifndef _GEOMETRY_DEF_H_
