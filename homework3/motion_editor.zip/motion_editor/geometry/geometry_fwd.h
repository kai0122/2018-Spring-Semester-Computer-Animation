#ifndef _GEOMETRY_FWD_H_
#define _GEOMETRY_FWD_H_

namespace geometry {
class Arrow;
class Ellipsoid;
class Sphere;
} // namespace geometry {

#endif // #ifndef _GEOMETRY_FWD_H_
