#ifndef _ACCLAIM_FWD_H_
#define _ACCLAIM_FWD_H_

namespace acclaim {
class Skeleton;
class Motion;
struct Bone;
} // namespace acclaim {

class Posture;

#endif // #ifndef _ACCLAIM_FWD_H_
