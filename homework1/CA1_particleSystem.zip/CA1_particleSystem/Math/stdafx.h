#pragma once

#include <string>
#include <sstream>

#include <math.h>
#include <fvec.h>		// SSE
#include <vector>
#include <set>
#include <string>

#include <stdio.h>
#include <stdlib.h>
#include <algorithm>
